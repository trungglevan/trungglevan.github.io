<?php
    require "dao.php";
    $sql = "SELECT * FROM loai";
    $result = select($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách loại hàng</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
    <h3 class="alert alert-success">QUẢN LÝ LOẠI HÀNG</h3>
        <table class="table">
            <thead class="alert-success">
                <tr>
                    <th></th>
                    <th>MÃ LOẠI</th>
                    <th>TÊN LOẠI</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($result as $loai) { extract($loai);?>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><?php echo $ma_loai; ?></td>
                    <td><?php echo $ten_loai; ?></td>
                    <td>
                        <a class="btn btn-default" href="index.php?act_sua&maLoai=<?php echo $ma_loai?>">Sửa</a>
                        <a class="btn btn-default" href="deleteLH.php?act_xoa&maLoai=<?php echo $ma_loai?>">Xóa</a>
                    </td>
                </tr>
            <?php } ?>

            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4">
                        <button id="check-all" type="button" class="btn btn-default">Chọn tất cả</button>
                        <button id="clear-all" type="button" class="btn btn-default">Bỏ chọn tất cả</button>
                        <button id="btn-delete" name="btn_delete" class="btn btn-default">Xóa các mục chọn</button>
                        <a href="index.php?act_add" class="btn btn-default">Nhập thêm</a>
                    </td>
                </tr>
            </tfoot>
        </table>
</body>
</html>