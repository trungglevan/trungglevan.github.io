<?php
require "dao.php";

if (isset($_POST['tenLoai'])) {
    $tenLoai = $_POST['tenLoai'];
    loai_insert($tenLoai);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loại hàng</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
        <h3 class="alert alert-success">QUẢN LÝ LOẠI HÀNG</h3>
        <form action="" method="post">
            <div class="form-group">
                <label for="">Mã loại</label>
                <input name="maLoai" value="auto number" class="form-control" readonly>
            </div>

            <div class="form-group">
                <label for="">Tên loại</label>
                <input name="tenLoai" class="form-control" type="text" required>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-default" value="Thêm">
                <button type="reset" class="btn btn-default">Nhập lại</button>
                <a href="index.php?act_list" class="btn btn-default">Danh sách</a>
            </div>
        </form>

</body>
</html>
