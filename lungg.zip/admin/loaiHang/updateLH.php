<?php
require "dao.php";
$conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
    if(!$conn) {
        die('Kết nôi thất bại DB!');
    }
if (isset($_GET['maLoai'])) {
    $maLoai = $_GET['maLoai'];
}
$sql_loai = "SELECT * FROM loai WHERE ma_loai = $maLoai";
$query_loai = mysqli_query($conn, $sql_loai);
if (isset($_POST['tenLoai'])) {
    $tenLoai = $_POST['tenLoai'];
    update($maLoai, $tenLoai);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loại hàng</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
        <h3 class="alert alert-success">UPDATE LOẠI HÀNG</h3>
        <form action="" method="post">
            <div class="form-group">
                <label for="">Mã loại</label>
                <input name="maLoai" value="auto number" class="form-control" readonly>
            </div>
            <?php $row_loai = mysqli_fetch_array($query_loai); { ?>
            <div class="form-group">
                <label for="">Tên loại</label>
                <input name="tenLoai" class="form-control" type="text" value="<?php echo $row_loai['ten_loai']; ?>" required>
            </div>
            <?php } ?>
            <div class="form-group">
                <input type="submit" class="btn btn-default" value="Lưu">
                <button type="reset" class="btn btn-default">Nhập lại</button>
                <a href="loaiHang/list.php" class="btn btn-default">Danh sách</a>
            </div>
        </form>

</body>
</html>
