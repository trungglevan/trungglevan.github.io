<?php
    require "../../global.php";
    extract($_REQUEST);
    if (exsit_param("act_list")) {
        $VIEW_NAME = "list.php";
    } else if (exsit_param("act_sua")) {
        $VIEW_NAME = "updateLH.php";
    } else if (exsit_param("act_xoa")) {
        // $VIEW_NAME = "deleteLH.php";
    } else {
        $VIEW_NAME = "addLH.php";
    }
    require "../layout.php";
?>