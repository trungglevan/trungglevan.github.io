<?php
    //Ket noi database
    function connection() {
        $servername = "localhost";
        $username = "trungglevan";
        $password = "220204Trungg@";
        $dbname = "xshop";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
    
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        }
        echo "Connected successfully";
        mysqli_close($conn);
    }
    
    //Them moi
    function loai_insert($tenLoai){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "INSERT INTO loai (ten_loai)
        VALUES ('$tenLoai')";
        if (mysqli_query($conn, $sql)) {
            // echo "New record created successfully!";
            header("Location:index.php?act_list");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        mysqli_close($conn);
    }

    function select($sql){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        // $sql = "SELECT * FROM loaihang";
        $result = mysqli_query($conn, $sql);
        $data=[];
        if ($result != null) {
        // output data of each row
        while ($row=mysqli_fetch_assoc($result)) {
            $data[]=$row;
        }
        }     
        mysqli_close($conn);
        return $data;
    }
    //Xoa
    function delete($maLoai){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "DELETE FROM loai WHERE ma_loai=$maLoai";

        if (mysqli_query($conn, $sql)) {
        header("Location:index.php?act_list");
        } else {
        echo "Error deleting record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }
    //Sua
    function update($maLoai, $tenLoai){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "UPDATE loai SET ten_loai='$tenLoai' WHERE ma_loai=$maLoai";

        if (mysqli_query($conn, $sql)) {
        header("location:index.php?act_list");
        } else {
        echo "Error updating record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }

?>