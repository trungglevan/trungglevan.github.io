<?php
    require "../../global.php";
    extract($_REQUEST);
    if (exsit_param("act_list")) {
        $VIEW_NAME = "listHH.php";
    } else if (exsit_param("act_sua")) {
        $VIEW_NAME = "updateHH.php";
    } else {
        $VIEW_NAME = "addHH.php";
    }
    require "../layout.php";
?>