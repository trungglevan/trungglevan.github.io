<?php
require "daoHH.php";
$conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
if(!$conn) {
   die('Kết nôi thất bại DB!');
}
$sql = "SELECT * FROM loai";
$result = select($sql);
function now() {
    return date('Y-m-d H:i:s');
}
if (isset($_GET['ma_hh'])) {
    $ma_hh = $_GET['ma_hh'];
}
$sql_hang_hoa = "SELECT * FROM hang_hoa WHERE ma_hh = $ma_hh";
$query_hang_hoa= mysqli_query($conn, $sql_hang_hoa);
if (isset($_POST['ten_hh']) && isset($_POST['don_gia']) && isset($_POST['giam_gia']) && isset($_FILES['hinh']) && isset($_POST['ma_loai']) && isset($_POST['mo_ta']) ){
    $ten_hh = $_POST['ten_hh'];
    $don_gia = $_POST['don_gia'];
    $giam_gia = $_POST['giam_gia'];
    $hinh = $_FILES['hinh']['name'];
    $ngay_nhap = date('Y-m-d H:i:s', strtotime(now()));
    // $ngay_nhap = $_POST['ngay_nhap'];
    $ma_loai = $_POST['ma_loai'];
    $dac_biet = $_POST['dac_biet'];
    $mo_ta= $_POST['mo_ta'];

    updateHH($ma_hh, $ten_hh, $don_gia, $giam_gia, $hinh, $ngay_nhap, $ma_loai, $dac_biet, $mo_ta);

    $source = $_FILES['hinh']['tmp_name'];
    $destination = __DIR__ . '/img/' . $_FILES['hinh']['name'];

    if (move_uploaded_file($source, $destination)) {
        echo 'Tải ảnh lên thành công!';
        // header('Location: index.php');
    } else {
        echo 'Tải ảnh lên thất bại!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hàng hóa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
    <h3 class="alert alert-success">QUẢN LÝ HÀNG HÓA</h3>
    <?php $row_hang_hoa = mysqli_fetch_array($query_hang_hoa); { ?>
    <form action="" method="post" class="row" enctype="multipart/form-data">
        <div class="form-group col-lg-4">
            <label for="">Mã Hàng hóa</label>
            <input name="ma_hh" value="auto number" class="form-control" readonly>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Tên Hàng hóa</label>
            <input name="ten_hh" class="form-control" type="text" value="<?php echo $row_hang_hoa['ten_hh']; ?>" required>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Đơn giá</label>
            <input name="don_gia" class="form-control" type="number" min="1000" step="1" value="<?php echo $row_hang_hoa['don_gia']; ?>" required>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Giảm giá</label>
            <input name="giam_gia" class="form-control" type="number" min="0" value="<?php echo $row_hang_hoa['giam_gia']; ?>" required>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Hình ảnh</label>
            <input name="hinh" class="form-control" type="file" value="<?php echo $row_hang_hoa['hinh']; ?>" required>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Loại hàng</label>
            <select name="ma_loai" class="form-control" input>
            <?php foreach ($result as $loai) { extract($loai);?>
            <option value="<?php echo $ma_loai; ?>"><?php echo $ten_loai;?></option>
            <?php } ?>
            </select>

        </div>

        <div class="form-group col-lg-4">
            <label for="">Hàng đặc biệt</label>
            <div class="form-control">
                <label for=""><input type="radio" name="dac_biet">Đặc biệt</label>
                <label for=""><input type="radio" name="dac_biet" checked>Bình thường</label>
            </div>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Ngày nhập</label>
            <input name="ngay_nhap" class="form-control" value="Tự Động" readonly>
        </div>

        <div class="form-group col-lg-4">
            <label for="">Số lượt xem</label>
            <input name="so_luot_xem" class="form-control" value="auto number" readonly>
        </div>

        <div class="form-group col-lg-12">
            <label for="">Mô tả</label><br>
            <textarea name="mo_ta" id="" cols="100%" rows="5"><?php echo $row_hang_hoa['mo_ta']; ?></textarea>
        </div>
        <?php } ?>
        <div class="form-group col-lg-12">
            <button type="submit" class="btn btn-default">Lưu</button>
            <button type="reset" class="btn btn-default">Nhập lại</button>
            <a href="hangHoa/listHH.php" class="btn btn-default">Danh sách</a>
        </div>
    </form>
</body>
</html>