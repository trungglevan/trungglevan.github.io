<?php
    require "daoHH.php";
    $sql = "SELECT * FROM hang_hoa";
    $result = select($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách hàng hóa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="text-center">
        <i class="fa-solid fa-backward-step fa-2xl btn"></i>
        <i class="fa-solid fa-angles-left fa-2xl btn"></i>
        <i class="fa-solid fa-angles-right fa-2xl btn"></i>
        <i class="fa-solid fa-forward-step fa-2xl btn"></i>
    </div>
    <h3 class="alert alert-success">QUẢN LÝ HÀNG HÓA</h3>
        <table class="table">
            <thead class="alert-success">
                <tr>
                    <th></th>
                    <th>MÃ HÀNG HÓA</th>
                    <th>TÊN HÀNG HÓA</th>
                    <th>ĐƠN GIÁ</th>
                    <th>GIẢM GIÁ</th>
                    <th>LƯỢT XEM</th>
                    <th>NGÀY NHẬP</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($result as $hang_hoa) { extract($hang_hoa);?>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><?php echo $ma_hh; ?></td>
                    <td><?php echo $ten_hh; ?></td>
                    <td><?php echo $don_gia; ?></td>
                    <td><?php echo $giam_gia; ?></td>
                    <td><?php echo $so_luot_xem; ?></td>
                    <td><?php echo $ngay_nhap; ?></td>
                    <td>
                        <a class="btn btn-default" href="index.php?act_sua&ma_hh=<?php echo $ma_hh?>">Sửa</a>
                        <a class="btn btn-default" href="deleteHH.php?ma_hh=<?php echo $ma_hh?>">Xóa</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4">
                        <button id="check-all" type="button" class="btn btn-default">Chọn tất cả</button>
                        <button id="clear-all" type="button" class="btn btn-default">Bỏ chọn tất cả</button>
                        <button id="btn-delete" name="btn_delete" class="btn btn-default">Xóa các mục chọn</button>
                        <a href="../hangHoa" class="btn btn-default">Nhập thêm</a>
                    </td>
                </tr>
            </tfoot>
        </table>
</body>
</html>