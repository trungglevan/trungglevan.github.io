<?php
    require "../../global.php";
    $VIEW_NAME = "trangChinh/home.php";
    require "../layout.php";
?>