<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="../trangChinh">Trang chủ</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="../loaiHang">Loại hàng</a></li>
      <li><a href="../hangHoa/">Hàng hóa</a></li>
      <li><a href="../khachHang/">Khách hàng</a></li>
      <li><a href="../binhLuan/">Bình luận</a></li>
      <li><a href="../thongKe/">Thông kê</a></li>
    </ul>
  </div>
</nav>
