<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thống kê</title>
</head>
<body>
    <h3 class="alert alert-success">THỐNG KÊ HÀNG HÓA TỪNG LOẠI</h3>
    <?php
        // if (strlen($MESSAGE)) {
        //     echo "<h5 class='alert alert-warning'>$MESSAGE</h5>";
        // }
    ?>
    <form action="index.php" method="post">
        <table class="table">
            <thead class="alert-success">
                <tr>
                    <th>LOẠI HÀNG</th>
                    <th>SỐ LƯỢNG</th>
                    <th>GIÁ CAO NHẤT</th>
                    <th>GIÁ THẤP NHÂT</th>
                    <th>GIÁ TRUNG BÌNH</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Đồng hồ</td>
                    <td>500</td>
                    <td>22.000.000VNĐ</td>
                    <td>1.000.000VNĐ</td>
                    <td>11.500.000VNĐ</td>
                </tr>

                <!-- <tr>
                    <td>Đồng hồ</td>
                    <td>500</td>
                    <td>22.000.000VNĐ</td>
                    <td>1.000.000VNĐ</td>
                    <td>11.500.000VNĐ</td>
                </tr> -->
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5">
                        <a href="index.php?act_BD" class="btn btn-default">Xem biểu đồ</a>
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>
</body>
</html>