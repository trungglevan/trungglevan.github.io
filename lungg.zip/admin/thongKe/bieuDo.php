<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biều đò</title>
</head>
<body>
    <h3 class="alert alert-success">BIỀU ĐỒ THỐNG KÊ</h3>
</body>
</html>