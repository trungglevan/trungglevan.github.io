<?php
    require "../../global.php";
    extract($_REQUEST);
    if (exsit_param("act_BD")) {
        $VIEW_NAME = "bieuDo.php";
    } else {
        $VIEW_NAME = "thongKe.php";
    }
    require "../layout.php";
?>