<?php
    require "daoKH.php";
    $sql = "SELECT * FROM khach_hang";
    $result = select($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách khách hàng</title>
</head>
<body>
    <h3 class="alert alert-success">QUẢN LÝ KHÁCH HÀNG</h3>
    <form action="index.php" method="post">
        <table class="table">
            <thead class="alert-success">
                <tr>
                    <th></th>
                    <th>MÃ KHÁCH HÀNG</th>
                    <th>HỌ VÀ TÊN</th>
                    <th>ĐỊA CHỈ EMAIL</th>
                    <th>HÌNH ẢNH</th>
                    <th>VAI TRÒ</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($result as $khach_hang) { extract($khach_hang);?>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><?php echo $ma_kh; ?></td>
                    <td><?php echo $ho_ten; ?></td>
                    <td><?php echo $email; ?></td>
                    <td><img src="img/<?php echo $khach_hang['hinh']; ?>" alt="" width="100"></td>
                    <td><?php if ($vai_tro == 1) {
                        echo "Nhân viên";
                    } else {
                        echo "Khách hàng";
                    }
                    ?></td>
                    <td>
                        <a class="btn btn-default" href="index.php?act_sua&ma_kh=<?php echo $ma_kh?>">Sửa</a>
                        <a class="btn btn-default" href="deleteKH.php?act_xoa&ma_kh=<?php echo $ma_kh?>">Xóa</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="7">
                        <button id="check-all" type="button" class="btn btn-default">Chọn tất cả</button>
                        <button id="clear-all" type="button" class="btn btn-default">Bỏ chọn tất cả</button>
                        <button id="btn-delete" name="btn_delete" class="btn btn-default">Xóa các mục chọn</button>
                        <a href="../khachHang" class="btn btn-default">Nhập thêm</a>
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>
</body>
</html>