<?php
    //Ket noi database
    function connection() {
        $servername = "localhost";
        $username = "trungglevan";
        $password = "220204Trungg@";
        $dbname = "xshop";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
    
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        }
        echo "Connected successfully";
        mysqli_close($conn);
    }
    
    // Them moi
    function khachHang_insert($ma_kh, $ho_ten, $mat_khau, $email, $hinh, $kich_hoat, $vai_tro){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "INSERT INTO khach_hang (ho_ten, mat_khau, email, hinh, kich_hoat, vai_tro)
        VALUES ('$ho_ten', '$mat_khau', '$email', '$hinh', $kich_hoat, $vai_tro)";
        if (mysqli_query($conn, $sql)) {
            // echo "New record created successfully!";
            header("Location:index.php?act_list");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        
        mysqli_close($conn);
    }
    

    function select($sql){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        // $sql = "SELECT * FROM loaihang";
        $result = mysqli_query($conn, $sql);
        $data=[];
        if ($result != null) {
        // output data of each row
        while ($row=mysqli_fetch_assoc($result)) {
            $data[]=$row;
        }
        }     
        mysqli_close($conn);
        return $data;
    }
    //Xoa
    function delete($ma_kh){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "DELETE FROM khach_hang WHERE ma_kh=$ma_kh";

        if (mysqli_query($conn, $sql)) {
        header("Location:index.php?act_list");
        } else {
        echo "Error deleting record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }
    //Sua
    function updateKH($ma_kh, $ho_ten, $mat_khau, $email, $hinh, $vai_tro){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "UPDATE khach_hang SET ho_ten='$ho_ten', mat_khau='$mat_khau', email='$email', hinh='$hinh', vai_tro='$vai_tro' WHERE ma_kh=$ma_kh";

        if (mysqli_query($conn, $sql)) {
        header("location:index.php?act_list");
        // echo "Record updated successfully";
        } else {
        echo "Error updating record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }
?>