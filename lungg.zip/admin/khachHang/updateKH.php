<?php
require "daoKH.php";
$conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
    if(!$conn) {
        die('Kết nôi thất bại DB!');
    }
if (isset($_GET['ma_kh'])) {
    $ma_kh = $_GET['ma_kh'];
}
$sql_khach_hang = "SELECT * FROM khach_hang WHERE ma_kh = $ma_kh";
$query_khach_hang = mysqli_query($conn, $sql_khach_hang);
if (isset($_POST['ho_ten']) && isset($_POST['mat_khau']) && isset($_POST['email']) && isset($_FILES['hinh']) && isset($_POST['vai_tro'])){
    $ho_ten = $_POST['ho_ten'];
    $mat_khau = $_POST['mat_khau'];
    $email = $_POST['email'];
    $hinh = $_FILES['hinh']['name'];
    $vai_tro = $_POST['vai_tro']; 

    updateKH($ma_kh, $ho_ten, $mat_khau, $email, $hinh, $vai_tro);

    // updateKH($ma_kh, $ho_ten, $mat_khau, $email, $hinh,$vai_tro);
    $source = $_FILES['hinh']['tmp_name'];
    $destination = __DIR__ . '/img/' . $_FILES['hinh']['name'];

    if (move_uploaded_file($source, $destination)) {
        echo 'Tải ảnh lên thành công!';
        // header('Location: index.php');
    } else {
        echo 'Tải ảnh lên thất bại!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khách hàng</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <h3 class="alert alert-success">QUẢN LÝ KHÁCH HÀNG</h3>
    <form action="" method="post" class="row" enctype="multipart/form-data">
    <?php $row_khach_hang = mysqli_fetch_array($query_khach_hang); { ?>
        <div class="form-group col-lg-6">
            <label for="">Họ và tên</label>
            <input name="ho_ten" class="form-control" type="text" value="<?php echo $row_khach_hang['ho_ten']; ?>" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Mật khẩu</label>
            <input name="mat_khau" class="form-control" type="text" value="<?php echo $row_khach_hang['mat_khau']; ?> " required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Nhập lại mât khẩu</label>
            <input name="nhapLaiMK" class="form-control" type="text" value="<?php echo $row_khach_hang['mat_khau']; ?>" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Địa chỉ Email</label>
            <input name="email" class="form-control" type="email" value="<?php echo $row_khach_hang['email']; ?>" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Hình ảnh</label>
            <input name="hinh" class="form-control" type="file" value="<?php echo $row_khach_hang['hinh']; ?>" required> 
        </div>

        <div class="form-group col-lg-6">
            <label for="">Vai trò</label>
            <div class="form-control">
                <label for=""><input type="radio" name="vai_tro" value="0">Khách hàng</label>
                <label for=""><input type="radio" name="vai_tro" value="1" checked>Nhân viên</label>
            </div>
        </div>
        <?php } ?>
        <div class="form-group col-lg-12">
            <button class="btn btn-default" type="submit">Lưu</button>
            <button type="reset" class="btn btn-default">Nhập lại</button>
            <a href="index.php?btn_list" class="btn btn-default">Danh sách</a>
        </div>
    </form>
</body>
</html>