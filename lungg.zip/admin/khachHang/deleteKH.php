<?php
require "daoKH.php";
if (isset($_GET['ma_kh'])) {
    $ma_kh = $_GET['ma_kh'];
}
if(isset($_GET['submit'])) {
    if($_GET['submit'] == 'Xóa') {
        delete($ma_kh);
    } else {
        header('Location: listKH.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản trị website</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        .text {
            font-size: 20px;
            font-family: sans-serif;
            text-align: center;
        }

        form {
            width: 500px;
            margin: 0 auto;
            border: 1px solid #ccc;
            padding: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
        }

        button {
            /* margin-top: 10px; */
            background-color: #008CBA;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #006495;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="row">
            <h1 class="alert alert-danger">QUẢN TRỊ WEBSITE</h1>
        </header>
        <nav class="row">
            <?php require '../menu.php';?>
        </nav>
        <div class="row">
        <form action="" method="get">
            <h1 class="text">Bạn có chắc chắn muốn xóa id = <?php echo $ma_kh; ?> </h1>
            <input type="hidden" name="ma_kh" value="<?php echo $ma_kh; ?>">
            <br>
            <button name="submit" value="Xóa">CÓ</button>
            <button name="submit" value="Hủy">HỦY</button>
        </form>
        </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>
