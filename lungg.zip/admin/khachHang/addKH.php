<?php
require "daoKH.php";
if (isset($_POST['ho_ten']) && isset($_POST['mat_khau']) && isset($_POST['email']) && isset($_FILES['hinh']) && isset($_POST['kich_hoat']) && isset($_POST['vai_tro'])){
    // $ma_kh = $_POST['ma_kh'];
    $ho_ten = $_POST['ho_ten'];
    $mat_khau = $_POST['mat_khau'];
    $email = $_POST['email'];
    $hinh = $_FILES['hinh']['name'];
    $kich_hoat = $_POST['kich_hoat'];
    $vai_tro = $_POST['vai_tro'];
    khachHang_insert($ma_kh, $ho_ten, $mat_khau, $email, $hinh, $kich_hoat, $vai_tro);
    // loai_insert($ma_kh, $ho_ten, $mat_khau, $email, $hinh, $kich_hoat, $vai_tro);
    $source = $_FILES['hinh']['tmp_name'];
    $destination = __DIR__ . '/img/' . $_FILES['hinh']['name'];

    if (move_uploaded_file($source, $destination)) {
        // echo 'Tải ảnh lên thành công!';
        header('Location: index.php?act_list');
    } else {
        echo 'Tải ảnh lên thất bại!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khách hàng</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <h3 class="alert alert-success">QUẢN LÝ KHÁCH HÀNG</h3>
    <form action="" method="post" class="row" enctype="multipart/form-data">
        <div class="form-group col-lg-6">
            <label for="">Mã khách hàng</label>
            <input name="ma_kh" class="form-control" type="text" readonly>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Họ và tên</label>
            <input name="ho_ten" class="form-control" type="text" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Mật khẩu</label>
            <input name="mat_khau" class="form-control" type="text" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Nhập lại mât khẩu</label>
            <input name="nhapLaiMK" class="form-control" type="text" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Địa chỉ Email</label>
            <input name="email" class="form-control" type="email" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Hình ảnh</label>
            <input name="hinh" class="form-control" type="file" required>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Kích hoạt</label><br>
            <div class="form-control">
                <label for=""><input type="radio" name="kich_hoat" value="0">Chưa kích hoạt</label>
                <label for=""><input type="radio" name="kich_hoat" value="1" checked>Kích hoạt</label>
            </div>
        </div>

        <div class="form-group col-lg-6">
            <label for="">Vai trò</label>
            <div class="form-control">
                <label for=""><input type="radio" name="vai_tro" value="0">Khách hàng</label>
                <label for=""><input type="radio" name="vai_tro" value="1" checked>Nhân viên</label>
            </div>
        </div>

        <div class="form-group col-lg-12">
            <button class="btn btn-default" type="submit">Thêm mới</button>
            <button type="reset" class="btn btn-default">Nhập lại</button>
            <a href="index.php?act_list" class="btn btn-default">Danh sách</a>
        </div>
    </form>
</body>
</html>