<?php
    // require "../khachHang/daoKH.php";
    require "../../global.php";
    extract($_REQUEST);
    if (exsit_param("act_list")) {
        $VIEW_NAME = "listKH.php";
    } else if (exsit_param("act_sua")) {
        $VIEW_NAME ="updateKH.php";
    } else {
        $VIEW_NAME = "addKH.php";
    }
    
    require "../layout.php";
?>