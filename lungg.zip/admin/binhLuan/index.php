<?php
    require "../../global.php";
    extract($_REQUEST);
    if (exsit_param("act_chiTietBL")) {
        $VIEW_NAME = "chiTietBL.php";
    } else {
        $VIEW_NAME = "binhLuan.php";
    }
    require "../layout.php";
?>