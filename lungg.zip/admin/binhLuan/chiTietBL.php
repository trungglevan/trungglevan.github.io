<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết bình luận</title>
</head>
<body>
    <h3 class="alert alert-success">CHI TIẾT BÌNH LUẬN</h3>
    <h3>HÀNG HÓA: Đồng hồ đeo tay</h3>
    <?php
        // if (strlen($MESSAGE)) {
        //     echo "<h5 class='alert alert-warning'>$MESSAGE</h5>";
        // }
    ?>
    <form action="index.php" method="post">
        <table class="table">
            <thead class="alert-success">
                <tr>
                    <th></th>
                    <th>NỘI DUNG</th>
                    <th>NGÀY BÌNH LUẬN</th>
                    <th>NGƯỜI BÌNH LUẬN</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="checkbox"></td>
                    <td>GOOD</td>
                    <td>2023-09-22</td>
                    <td>LVT2202</td>
                    <td><a href="#" class="btn btn-default">Xóa</a></td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5">
                        <button id="check-all" type="button" class="btn btn-default">Chọn tất cả</button>
                        <button id="clear-all" type="button" class="btn btn-default">Bỏ chọn tất cả</button>
                        <button id="btn-delete" name="btn_delete" class="btn btn-default">Xóa các mục chọn</button>
                        <a href="#" class="btn btn-default">Nhập thêm</a>
                    </td>
                </tr>
            </tfoot>
        </table>
    </form>
</body>
</html>