<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bình luận</title>
</head>
<body>
    <h3 class="alert alert-success">TỔNG HỢP BÌNH LUẬN</h3>
    <?php
        // if (strlen($MESSAGE)) {
        //     echo "<h5 class='alert alert-warning'>$MESSAGE</h5>";
        // }
    ?>
    <form action="index.php" method="post">
        <table class="table">
            <thead class="alert-success">
                <tr>
                    <th>HÀNG HÓA</th>
                    <th>SỐ BÌNH LUẬN</th>
                    <th>MỚI NHẤT</th>
                    <th>CŨ NHÂT</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Đồng hồ đeo tay</td>
                    <td>200</td>
                    <td>2023-09-22</td>
                    <td>2022-12-22</td>
                    <td><a href="index.php?act_chiTietBL" class="btn btn-default">Chi tiết</a></td>
                </tr>
            </tbody>
            <!-- <tfoot>
                <tr>
                    <td colspan="4">
                        <button id="check-all" type="button" class="btn btn-default">Chọn tất cả</button>
                        <button id="clear-all" type="button" class="btn btn-default">Bỏ chọn tất cả</button>
                        <button id="btn-delete" name="btn_delete" class="btn btn-default">Xóa các mục chọn</button>
                        <a href="#" class="btn btn-default">Nhập thêm</a>
                    </td>
                </tr>
            </tfoot> -->
        </table>
    </form>
</body>
</html>