<?php
    //Ket noi database
    function connection() {
        $servername = "localhost";
        $username = "trungglevan";
        $password = "220204Trungg@";
        $dbname = "xshop";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
    
        // Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        }
        echo "Connected successfully";
        mysqli_close($conn);
    }
    
    // Them moi
    function binhLuan_insert($noi_dung, $ngay_bl, $ma_kh, $ma_hh){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "INSERT INTO binh_luan (noi_dung, ngay_bl, ma_kh, ma_hh )
        VALUES ('$noi_dung', '$ngay_bl', '$ma_kh', '$ma_hh')";
        if (mysqli_query($conn, $sql)) {
            echo "New record created successfully!";
            // header("Location:index.php");
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        
        mysqli_close($conn);
    }
    

    function select($sql){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }

        $result = mysqli_query($conn, $sql);
        $data=[];
        if ($result != null) {
        // output data of each row
        while ($row=mysqli_fetch_assoc($result)) {
            $data[]=$row;
        }
        }     
        mysqli_close($conn);
        return $data;
    }
    //Xoa
    function delete($ma_hh){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "DELETE FROM hang_hoa WHERE ma_hh=$ma_hh";

        if (mysqli_query($conn, $sql)) {
        header("Location:index.php");
        } else {
        echo "Error deleting record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }
    //Sua
    function updateHH($ma_hh, $ten_hh, $don_gia, $giam_gia, $hinh, $ngay_nhap, $ma_loai, $dac_biet, $mo_ta){
        $conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
        if(!$conn) {
            die('Kết nôi thất bại DB!');
        }
        $sql = "UPDATE hang_hoa SET ten_hh='$ten_hh', don_gia='$don_gia', giam_gia='$giam_gia', hinh='$hinh', ngay_nhap='$ngay_nhap', ma_loai='$ma_loai', mo_ta='$mo_ta' WHERE ma_hh=$ma_hh";

        if (mysqli_query($conn, $sql)) {
        // header("location:index.php");
        echo "Record updated successfully";
        } else {
        echo "Error updating record: " . mysqli_error($conn);
        }

        mysqli_close($conn);
    }
?>