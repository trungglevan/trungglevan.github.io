<?php
$conn = mysqli_connect('localhost', 'trungglevan', '220204Trungg@', 'xshop');
if(!$conn) {
    die('Kết nôi thất bại DB!');
}
$results = mysqli_query($conn, "SELECT * FROM loai");
$results_hh = mysqli_query($conn, "SELECT * FROM hang_hoa");

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Trang chủ</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    .itemNB {
      margin: 10px;
      border: 1px solid black;
      border-radius: 5px;
      width: 272.5px;
    }

    .img-itemNB {
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 5px;
    }
  </style>
</head>

<body>
  <div class="container">
    <header class="row">
      <h1 class="alert alert-success">SIÊU THỊ TRỰC TUYẾN</h1>
    </header>
    <nav class="row">
      <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">Trang chủ</a>
          </div>
          <ul class="nav navbar-nav">
            <li><a href="#">Giới thiệu</a></li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Sản phẩm
                <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Đồng hồ</a></li>
                <li><a href="#">Nước hoa</a></li>
                <li><a href="#">Máy ảnh</a></li>
              </ul>
            </li>
            <li><a href="#">Liên hệ</a></li>
            <li><a href="#">Hỏi đáp</a></li>
          </ul>
        </div>
      </nav>

    </nav>
    <div class="row">
      <article class="col-sm-9">
        <!-- slideshow -->
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item active">
              <img src="https://daffar.vn/wp-content/uploads/2017/10/banner-nuoc-hoa.jpg" alt="Los Angeles"
                style="width:100%; height: 300px;">
            </div>

            <div class="item">
              <img
                src="https://cdn.galle.vn/media/amasty/shopby/option_images/thuong-hieu-dong-ho-hegner-banner_1602757303.jpeg"
                alt="Chicago" style="width:100%; height: 300px;">
            </div>

            <div class="item">
              <img src="https://images.acer.com/is/image/acer/MYGM-primarybanner:Primary-Hero-XL" alt="New york"
                style="width:100%; height: 300px;">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
        <!-- items -->
        <div class="row list-item">
          <?php while ($row = mysqli_fetch_array($results_hh)) { ?>
            <div class="col-sm-4 itemNB">
              <div class="img-itemNB">
                <a href="site/sanPhamCT.php"><img class="img-rounded"
                    src="admin/hangHoa/img/<?php echo $row['hinh']; ?>"
                    alt="" width="200" height="200"></a>
              </div>
              <div class="price">
                <h3><?php echo $row['don_gia'] . "VNĐ"; ?></h3>
              </div>
              <div class="name-item">
                <p><?php echo $row['ten_hh']; ?></p>
              </div>
            </div>
            <?php } ?>
        </div>
      </article>

      <aside class="col-sm-3">
        <!-- Tài khoản -->
        <div class="panel panel-default">
          <div class="panel-heading">TÀI KHOẢN</div>
          <div class="panel-body">
            <form action="/action_page.php">
              <div class="form-group">
                <label for="">Tên đăng nhập</label>
                <input type="tenDN" class="form-control" name="tenDangNhap">
              </div>
              <div class="form-group">
                <label for="">Mật khẩu</label>
                <input type="password" class="form-control" name="matKhau">
              </div>
              <div class="form-group form-control">
                <label><input type="checkbox"></label>
                <label for="checkbox">Ghi nhớ tài khoản?</label>
              </div>
              <div class="form-group">
                <button name="btn_login" class="btn btn-default">Đăng nhập</button><br>
                <li><a href="site/quenMK.php">Quên mật khẩu</a></li>
                <li><a href="site/register.php">Đăng ký tài khoản</a></li>
              </div>
            </form>
          </div>
        </div>
        <!-- Danh mục -->
        <div class="panel panel-default">
          <div class="panel-heading">DANH MỤC</div>
          <div class="panel-body">
            <div class="list-group">
            <?php while ($row = mysqli_fetch_array($results)) { ?>
              <a href="#" class="list-group-item"><?php echo $row['ten_loai']; ?></a>
              <!-- <a href="#" class="list-group-item">Máy tính xách tay</a>
              <a href="#" class="list-group-item">Máy ảnh</a>
              <a href="#" class="list-group-item">Điện thoại</a>
              <a href="#" class="list-group-item">Nước hoa</a>
              <a href="#" class="list-group-item">Nữ trang</a>
              <a href="#" class="list-group-item">Nón thời trang</a>
              <a href="#" class="list-group-item">Túi xách du lịch</a> -->
            <?php } ?>
            </div>
          </div>
          <div class="panel-footer">
            <input type="text" class="form-control" placeholder="Từ khóa tìm kiếm">
          </div>
        </div>
        <!-- Top 10 yêu thích -->
        <div class="panel panel-default">
          <div class="panel-heading">TOP 10 YÊU THÍCH</div>
          <div class="panel-body">
            <div class="img" style="margin-bottom: 10px;">
              <img class="img-thumbnail"
                src="https://bossluxurywatch.vn/uploads/san-pham/rolex/datejust-1/rolex-datejust-31-278271-mat-so-chocolate-nam-kim-cuong.png"
                alt="" width="40" height="40">
              <a href="#">ROLEX DATEJUST</a>
            </div>
            <div class="img" style="margin-bottom: 10px;">
              <img class="img-thumbnail"
                src="https://mayanhhoangto.com/wp-content/uploads/2019/10/M%C3%A1y-%E1%BA%A3nh-phim-Canon.jpg" alt=""
                width="40" height="40">
              <a href="#">MÁY ẢNH CƠ</a>
            </div>
            <div class="img" style="margin-bottom: 10px;">
              <img class="img-thumbnail"
                src="https://product.hstatic.net/1000360022/product/dsc09101_be3296fc810745eda912ff6100eb46d2_large.jpg"
                alt="" width="40" height="40">
              <a href="#">NÓN</a>
            </div>
            <div class="img" style="margin-bottom: 10px;">
              <img class="img-thumbnail" src="https://format.vn/images/products/original/milan_1628058566.png" alt=""
                width="40" height="40">
              <a href="#">MILAN</a>
            </div>
          </div>
        </div>
      </aside>
    </div>
    <footer class="row alert alert-success text-center">Lungg</footer>
  </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>