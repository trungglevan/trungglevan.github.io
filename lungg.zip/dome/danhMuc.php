<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh mục</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <!-- <style>
        body {
            font-family: sans-serif;
            background-color: #ffffff;
            color: #333333;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .card-header {
            width: 100%px;
            background-color: #E3E3E3;
            padding: 20px 0;
            border-radius: 5px;
        }

        li {
            float: left;
            margin-right: 20px;
            line-height: 20px;
        }

        a {
            text-decoration: none;
            color: #333333;
        }

        .form{
            border: 1px solid #E3E3E3;
            margin: 20px 0 0 0;
        }
    </style> -->
    <style>
        a{
            color: black;
        }
    </style>
</head>
<body>
    <div class="container form">
        <div class="card">
            <div class="card-header" style="border-bottom: 0 !important">DANH MỤC</div>
            <div class="card-text">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-action"><a href="#">Đồng hồ</a></li>
                    <li class="list-group-item list-group-item-action"><a href="#">Nhẫn</a></li>
                    <li class="list-group-item list-group-item-action"><a href="#">Vòng tay</a></li>
                </ul>
            </div> 
            <div class="card-footer" style="border-top: 0 !important">
                <input type="text" placeholder="Từ khóa tìm kiếm" class="form-control" />
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</html>