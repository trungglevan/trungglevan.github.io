<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản trị website</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<body>
    <div class="container">
        <header class="row">
            <h1 class="alert alert-danger">QUẢN TRỊ WEBSITE</h1>
        </header>
        <nav class="row">
            <?php require 'menu.php';?>
        </nav>
        <div class="row">
            <article class="col-sm-9">
                <div class="row">
                    <?php
                        // if(isset($_GET['act'])){
                        //     $act = $_GET['act'];
                        //     switch ($act) {
                        //         case 'addLH':
                        //             include "loaiHang/addLH.php";
                        //             break;
                                
                        //         default:
                        //         include "home.php";
                        //             break;
                        //     }
                        // }else {
                        //     include "home.php";
                        // }
                        require 'hangHoa/addHH.php';
                    ?>
                </div>
            </article>
            <aside class="col-sm-3">
                <!--Login-->
                <?php require 'login.php' ?>

                <!--Catalog-->
                <?php require 'danhMuc.php' ?>

                <!--Favorite-->
                <?php ?>
            </aside>
        </div>
        <footer class="row alert alert-success">Không biết</footer>
    </div>
</body>
<!-- <script>
    $(function(){
        $(".datepicker").datepicker({dateFormat: 'yy-mm-dd'});
    });
</script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
</html>