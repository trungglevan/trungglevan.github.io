<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top 10 sản phẩm yêu thích</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">TOP 10 YÊU THÍCH</div>
            <div class="card-body">
                <div class="container">
                    <div class="container-item">
                        <img src="https://vcdn-giaitri.vnecdn.net/2020/02/24/ssd3-0224-00-1582512209-8829-1582512359.jpg" alt="Đồng hồ Rolex" width="166" height="126" class="img-thumbnail">
                        <a href="#">Đồng hồ Rolex</a>
                    </div>

                    <div class="container-item">
                        <img src="https://vcdn-giaitri.vnecdn.net/2020/02/24/ssd3-0224-00-1582512209-8829-1582512359.jpg" alt="Đồng hồ Rolex" width="166" height="126" class="img-thumbnail">
                        <a href="#">Đồng hồ Rolex</a>
                    </div>

                    <div class="container-item">
                        <img src="https://vcdn-giaitri.vnecdn.net/2020/02/24/ssd3-0224-00-1582512209-8829-1582512359.jpg" alt="Đồng hồ Rolex" width="166" height="126" class="img-thumbnail">
                        <a href="#">Đồng hồ Rolex</a>
                    </div>

                    <div class="container-item">
                        <img src="https://vcdn-giaitri.vnecdn.net/2020/02/24/ssd3-0224-00-1582512209-8829-1582512359.jpg" alt="Đồng hồ Rolex" width="166" height="126" class="img-thumbnail">
                        <a href="#">Đồng hồ Rolex</a>
                    </div>

                    <div class="container-item">
                        <img src="https://vcdn-giaitri.vnecdn.net/2020/02/24/ssd3-0224-00-1582512209-8829-1582512359.jpg" alt="Đồng hồ Rolex" width="166" height="126" class="img-thumbnail">
                        <a href="#">Đồng hồ Rolex</a>
                    </div>
                    
                </div>
            </div> 
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</html>