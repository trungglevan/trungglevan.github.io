<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-3">
        <div class="d-flex justify-content-around mb-3">
            <div class="p-2 border">
                <div class="img-fluid">
                    <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m126234-0051_collection_upright_landscape.png" alt="Đồng hồ Rolex" width="200" height="200">
                </div>
                <div class="price">
                    <span>600.000.000VNĐ</span>
                </div>
                <div class="content">Đồng hồ Rolex</div>
            </div>
            <div class="p-2 border">
                <div class="img-fluid">
                        <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m126234-0051_collection_upright_landscape.png" alt="Đồng hồ Rolex" width="200" height="200">
                    </div>
                    <div class="price">
                        <span>600.000.000VNĐ</span>
                    </div>
                    <div class="content">Đồng hồ Rolex</div>
                </div>
            <div class="p-2 border">
                <div class="img-fluid">
                        <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m126234-0051_collection_upright_landscape.png" alt="Đồng hồ Rolex" width="200" height="200">
                    </div>
                    <div class="price">
                        <span>600.000.000VNĐ</span>
                    </div>
                    <div class="content">Đồng hồ Rolex</div>
            </div>
        </div>
    </div>

    <div class="container mt-3">
        <div class="d-flex justify-content-around mb-3">
            <div class="p-2 border">
                <div class="img-fluid">
                    <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m126234-0051_collection_upright_landscape.png" alt="Đồng hồ Rolex" width="200" height="200">
                </div>
                <div class="price">
                    <span>600.000.000VNĐ</span>
                </div>
                <div class="content">Đồng hồ Rolex</div>
            </div>
            <div class="p-2 border">
                <div class="img-fluid">
                        <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m126234-0051_collection_upright_landscape.png" alt="Đồng hồ Rolex" width="200" height="200">
                    </div>
                    <div class="price">
                        <span>600.000.000VNĐ</span>
                    </div>
                    <div class="content">Đồng hồ Rolex</div>
                </div>
            <div class="p-2 border">
                <div class="img-fluid">
                        <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m126234-0051_collection_upright_landscape.png" alt="Đồng hồ Rolex" width="200" height="200">
                    </div>
                    <div class="price">
                        <span>600.000.000VNĐ</span>
                    </div>
                    <div class="content">Đồng hồ Rolex</div>
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</html>