<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đổi mật khẩu</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>

<body>
    <div class="container">
        <h1 class="alert alert-danger">ĐỔI MẬT KHẨU</h1>
        <form action="">
            <div class="form-group">
                <label for="">Tên đăng nhập</label>
                <input type="text" name="tenDN" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Mật khẩu cũ</label>
                <input type="password" name="matKhau" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Mật khẩu mới</label>
                <input type="password" name="matKhau" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Xác nhận mật khẩu mới</label>
                <input type="password" name="matKhau" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Đổi mật khẩu</button>
        </form>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>