<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>

<body>
    <div class="container">
        <h1 class="alert alert-danger">ĐĂNG NHẬP</h1>
        <form action="">
            <div class="form-group">
                <label for="">Tên đăng nhập</label>
                <input type="text" name="tenDN" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Mật khẩu:</label>
                <input type="password" name="matKhau" class="form-control">
            </div>
            <div class="form-group form-check form-control">
                <label class="form-check-label">
                    <input class="form-check-input" type="checkbox"> Ghi nhớ tài khoản?
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Đăng nhập</button>
        </form>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>