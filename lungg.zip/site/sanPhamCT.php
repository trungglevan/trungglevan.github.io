<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        .image {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <header class="row">
            <h1 class="alert alert-success">SIÊU THỊ TRỰC TUYẾN</h1>
        </header>
        <nav class="row">
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../">Trang chủ</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="#">Giới thiệu</a></li>
                <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Sản phẩm
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="#">Đồng hồ</a></li>
                    <li><a href="#">Nước hoa</a></li>
                    <li><a href="#">Máy ảnh</a></li>
                </ul>
                </li>
                <li><a href="#">Liên hệ</a></li>
                <li><a href="#">Hỏi đáp</a></li>
            </ul>
            </div>
        </nav>

    </nav>
        <div class="row">
            <article class="col-sm-9">
                <!-- Thông tin sản phâm -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="image">
                            <img src="https://rolex.dafc.com.vn/wp-content/uploads/2023/05/m226627-0001_collection_upright_landscape.png"
                                alt="" width="340px" height="380px">
                        </div>
                        <div class="information">
                            <li>Mã hàng hóa: 1</li>
                            <li>Tên hàng hóa: Rolex YACHT-MASTER 42</li>
                            <li>Đơn giá: 200.00.VNĐ</li>
                            <li>Giảm giá: 0%</li>
                        </div>
                        <div class="content">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora saepe rem debitis dolor
                            corrupti
                            assumenda sapiente enim nesciunt repellendus voluptates?
                        </div>
                    </div>
                </div>
                <!-- Bình luận -->
                <div class="panel panel-default">
                    <div class="panel-heading">BÌNH LUẬN</div>
                    <div class="panel-body">
                        <li>Good</li>
                        <li>Sản phẩm đẹp</li>
                    </div>
                    <div class="panel-footer">
                        <div class="">
                            <input type="text" class="form-control" name="noi_dung">
                            <button type="submit" class="btn btn-default">Gửi</button>
                        </div>
                    </div>
                </div>
                <!-- Hàng cùng loại -->
                <div class="panel panel-default">
                    <div class="panel-heading">HÀNG CÙNG LOẠI</div>
                    <div class="panel-body">
                        <li>Rolex</li>
                        <li>Omega</li>
                        <li>Rado</li>
                    </div>
                </div>
            </article>

            <aside class="col-sm-3">
                <!-- Tài khoản -->
                <div class="panel panel-default">
                    <div class="panel-heading">TÀI KHOẢN</div>
                    <div class="panel-body">
                        <form action="/action_page.php">
                            <div class="form-group">
                                <label for="">Tên đăng nhập</label>
                                <input type="tenDN" class="form-control" name="tenDangNhap">
                            </div>
                            <div class="form-group">
                                <label for="">Mật khẩu</label>
                                <input type="password" class="form-control" name="matKhau">
                            </div>
                            <div class="form-group form-control">
                                <label><input type="checkbox"></label>
                                <label for="checkbox">Ghi nhớ tài khoản?</label>
                            </div>
                            <div class="form-group">
                                <button name="btn_login" class="btn btn-default">Đăng nhập</button><br>
                                <li><a href="quenMK.php">Quên mật khẩu</a></li>
                                <li><a href="register.php">Đăng ký tài khoản</a></li>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Danh mục -->
                <div class="panel panel-default">
                    <div class="panel-heading">DANH MỤC</div>
                    <div class="panel-body">
                        <div class="list-group">
                            <a href="#" class="list-group-item">Đồng hồ đeo tay</a>
                            <a href="#" class="list-group-item">Máy tính xách tay</a>
                            <a href="#" class="list-group-item">Máy ảnh</a>
                            <a href="#" class="list-group-item">Điện thoại</a>
                            <a href="#" class="list-group-item">Nước hoa</a>
                            <a href="#" class="list-group-item">Nữ trang</a>
                            <a href="#" class="list-group-item">Nón thời trang</a>
                            <a href="#" class="list-group-item">Túi xách du lịch</a>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <input type="text" class="form-control" placeholder="Từ khóa tìm kiếm">
                    </div>
                </div>
                <!-- Top 10 yêu thích -->
                <div class="panel panel-default">
                    <div class="panel-heading">TOP 10 YÊU THÍCH</div>
                    <div class="panel-body">
                        <div class="img" style="margin-bottom: 10px;">
                            <img class="img-thumbnail"
                                src="https://bossluxurywatch.vn/uploads/san-pham/rolex/datejust-1/rolex-datejust-31-278271-mat-so-chocolate-nam-kim-cuong.png"
                                alt="" width="40" height="40">
                            <a href="#">ROLEX DATEJUST</a>
                        </div>
                        <div class="img" style="margin-bottom: 10px;">
                            <img class="img-thumbnail"
                                src="https://mayanhhoangto.com/wp-content/uploads/2019/10/M%C3%A1y-%E1%BA%A3nh-phim-Canon.jpg"
                                alt="" width="40" height="40">
                            <a href="#">MÁY ẢNH CƠ</a>
                        </div>
                        <div class="img" style="margin-bottom: 10px;">
                            <img class="img-thumbnail"
                                src="https://product.hstatic.net/1000360022/product/dsc09101_be3296fc810745eda912ff6100eb46d2_large.jpg"
                                alt="" width="40" height="40">
                            <a href="#">NÓN</a>
                        </div>
                        <div class="img" style="margin-bottom: 10px;">
                            <img class="img-thumbnail"
                                src="https://format.vn/images/products/original/milan_1628058566.png" alt="" width="40"
                                height="40">
                            <a href="#">MILAN</a>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
    </div>
    <footer class="row alert alert-success text-center">Lungg</footer>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>