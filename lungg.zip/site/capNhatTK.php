<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý tài khoản</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        img {
            height: 200px;
            width: 200px;
        }

        .form {
            float: right;
            width: 70%;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="alert alert-danger">CẬP NHẬP TÀI KHOẢN</h1>
        <img src="https://haycafe.vn/wp-content/uploads/2021/11/hinh-anh-hoat-hinh-de-thuong-cute-dep-nhat.jpg"
            alt="Ảnh đại diện">
        <form action="" class="form">
            <div class="form-group">
                <label for="">Tên Đăng Nhập</label>
                <input name="tenDangNhap" value="LVT2202" class="form-control" readonly>
            </div>
            <div class="form-group">
                <label for="">Họ và tên</label>
                <input type="text" name="hoVaTen" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Địa chỉ email</label>
                <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Hình ảnh</label>
                <input type="file" name="hinhAnh" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Cập nhập</button>
        </form>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</html>