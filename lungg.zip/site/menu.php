        <!-- slideshow -->
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item active">
              <img src="https://daffar.vn/wp-content/uploads/2017/10/banner-nuoc-hoa.jpg" alt="Los Angeles"
                style="width:100%; height: 300px;">
            </div>

            <div class="item">
              <img
                src="https://cdn.galle.vn/media/amasty/shopby/option_images/thuong-hieu-dong-ho-hegner-banner_1602757303.jpeg"
                alt="Chicago" style="width:100%; height: 300px;">
            </div>

            <div class="item">
              <img src="https://images.acer.com/is/image/acer/MYGM-primarybanner:Primary-Hero-XL" alt="New york"
                style="width:100%; height: 300px;">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
        <!-- items -->
        <div class="row list-item">
          <?php while ($row = mysqli_fetch_array($results_hh)) { ?>
            <div class="col-sm-4 itemNB">
              <div class="img-itemNB">
                <a href="sanPhamCT.php"><img class="img-rounded"
                    src="admin/hangHoa/img/<?php echo $row['hinh']; ?>"
                    alt="" width="200" height="200"></a>
              </div>
              <div class="price">
                <h3><?php echo $row['don_gia']; ?></h3>
              </div>
              <div class="name-item">
                <p><?php echo $row['ten_hh']; ?></p>
              </div>
            </div>
            <?php } ?>
        </div>