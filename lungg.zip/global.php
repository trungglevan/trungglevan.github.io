<?php
    $ROOT_URL = "/duAnMau";
    $ADMIN_URL = "$ROOT_URL/admin";
    $SITE_URL = "$ROOT_URL/site";
    $DAO_URL = "$ROOT_URL/dao";
    function exsit_param($fieldname){
        return array_key_exists($fieldname, $_REQUEST);
    }
?>