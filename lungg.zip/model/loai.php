<?php
    function loai_selectall(){
        $sql = "SELECT * FROM loai";
        return pdo_query($sql);
    }

    //Them loai
    function loai_insert($tenLoai){
        $sql = "INSERT INTO loai(ten_loai) values(?) ";
        pdo_execute($sql, $tenLoai);
    }
?>