const url = 'https://api-ecom.duthanhduoc.com/me';
const token = localStorage.getItem("token");
console.log(token);
fetch(url, {
    headers: {
        'Authorization': `${token}`
    }
})
    .then(response => response.json())
    .then(data => {
        // Xử lý dữ liệu trả về từ API
        console.log(data);
    })
    .catch(error => {
        // Xử lý lỗi
        console.error('Error:', error);
    });