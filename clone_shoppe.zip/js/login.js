const token = localStorage.getItem('token');
if (token) {
    window.location.href = "/";
}
const formLogin = document.querySelector(".form-login-register")
formLogin.addEventListener("submit", async (e) => {
    e.preventDefault()
    const email = document.getElementsByName("email")[0].value
    const password = document.getElementsByName("password")[0].value
    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    };

    fetch("https://api-ecom.duthanhduoc.com/login", options)
        .then(response => {
            if (response.status == 200) {
                alert('Đăng nhập thành công');
                window.location.href = "index.html";
                return response.json();
            }
            if (response.status == 422) {
                alert('Email hoặc mật khẩu không đúng!');
            }
        }) // Chuyển đổi response sang JSON
        .then(data => {
            const dataUSer = data.data;
            localStorage.setItem('token', JSON.stringify(dataUSer.access_token));
        })
        .catch(error => {
            alert.error('Lỗi khi thực hiện POST request:', error);
            // Xử lý lỗi ở đây
        });
})


