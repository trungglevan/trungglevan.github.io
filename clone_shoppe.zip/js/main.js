const loadPage = () => {
  const token = localStorage.getItem('token');
  if (token) {
    document.getElementsByClassName("container-auth")[0].style.display = 'none'
    document.getElementsByClassName("container-user")[0].style.display = 'block';
  } else {
    document.getElementsByClassName("container-auth")[0].style.display = 'block'
    document.getElementsByClassName("container-user")[0].style.display = 'none';
  }

  fetcListProduct()
}


document.getElementById("logout").onclick = function () {
    localStorage.removeItem("token");
    loadPage()
    // window.location.reload();
}

const fetcListProduct = async () => {
  const response = await fetch("https://api-ecom.duthanhduoc.com/products?page=1&limit=30");
  const products = await response.json();
  console.log(products);
  console.log(products.data.products);
  if (products.data.products.length > 0) {
    const items = document.querySelector(".container-products");
    let htmlInner = ""
    products.data.products.map(product => {
      htmlInner += `<div class="col-2 container-item">
            <div class="item">
            <a href="detalitem.html?id=${product._id}">
            <div class="img">
              <img src="${product.image}" alt="">
            </div>
            <div class="name">${product.name}</div>
            </a>
              <div class="price">${product.price}</div>
            </div>
            </div>`
    })
    items.innerHTML = htmlInner
  }
}

loadPage()
