const swiper = new Swiper('.swiper', {
    // Optional parameters
    //   direction: 'vertical',
    loop: true,

    // If we need pagination
    pagination: {
        el: '.swiper-pagination',
    },

    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

    slidesPerView: 5
});
let imgPreview = document.querySelector(".container-img-priview")
document.addEventListener("click", (e) => {
    if (e.target.tagName == "IMG" && e.target.parentNode.className.includes("swiper-slide") == true) {
        // console.log("clicked");
        imgPreview.innerHTML = `<img src=${e.target.src} alt="">`;
    }
})


document.addEventListener("DOMContentLoaded", () => {
    let url = new URLSearchParams(window.location.search);
    let productId = url.get('id');
    console.log(productId);

    const fetcListProductDetail = async () => {

        const response = await fetch("https://api-ecom.duthanhduoc.com/products/" + productId);
        const products = await response.json();
        console.log(products.data);
        const items = document.querySelector(".container-body-detal-item");

        items.innerHTML = `
        <div class="container-detal-item col-5">
        <div class="detal-item-img">
            <div class="container-img-priview">
                <img src="${products.data.image}" alt="">
            </div>
            <div class="swiper">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                    <div class="swiper-slide" style="width:100px;">
                        <img src="${products.data.images[0]}" alt="">
                    </div>
                    <div class="swiper-slide" style="width:100px;">
                        <img src="${products.data.images[1]}" alt="">
                    </div>
                    <div class="swiper-slide" style="width:100px;">
                        <img src="${products.data.images[2]}" alt="">
                    </div>
                    <div class="swiper-slide" style="width:100px;">
                        <img src="${products.data.images[3]}" alt="">
                    </div>
                    <div class="swiper-slide" style="width:100px;">
                        <img src="${products.data.images[4]}" alt="">
                    </div>
                    <div class="swiper-slide" style="width:100px;">
                        <img src="${products.data.images[5]}" alt="">
                    </div>
                </div>
                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>

                <!-- If we need navigation buttons -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
    </div>
        <div class="detal-item-content col-7">
        <div class="name-item">
            ${products.data.name}
        </div>
        <div class="start-item">
            <div class="start">4.6 sao</div>
            <div class="evaluate">5.5k Đánh giá</div>
            <div class="sold">16.7k đã bán</div>
            <div class="report">Tố cáo</div>
        </div>
        <div class="price-item">
            <span class="price-item-old">${products.data.price_before_discount}</span>
            <span class="price-item-new">${products.data.price}</span>
        </div>
        <div class="quantity">
            <span>Số lượng</span>
            <input type="number" min="1">
            <span>${products.data.quantity}</span>
        </div>
        <div class="detal-btn">
            <button class="add-cart">Thêm vào giỏ hàng</button>
            <button class="buy-now">Mua ngay</button>
        </div>
    </div>
        `;

        const mota = document.querySelector(".mo-ta-san-pham");

        mota.innerHTML =`
        <div class="mo-ta-san-pham">
            <div class="title">Mô tả sản phẩm</div>
            <div class="content">
                ${products.data.description}
            </div>
        </div>
        `;

    }
    fetcListProductDetail()

});

