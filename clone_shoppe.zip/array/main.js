function findSubsets(array) {
    const subsets = [];

    function backtrack(startIndex, currentSubset) {
        subsets.push(currentSubset.slice());

        for (let i = startIndex; i < array.length; i++) {
            currentSubset.push(array[i]);
            backtrack(i + 1, currentSubset);
            currentSubset.pop();
        }
    }

    backtrack(0, []);
    return subsets;
}
const sumNumber = (arr) => {
    return arr.reduce((acc, item) => {
        return acc + item
    }, 0)
}
// Sử dụng ví dụ:
const array = [1, 2, 3, -3, 4, 6, 7, -8];
const target = 12;

const handleMain = (array, target) => {
    const result = []
    const allSubsets = findSubsets(array);
    allSubsets.forEach((arr) => {
        if (sumNumber(arr) === target) {
            result.push(arr);
        }
    })
    return result;
}

console.log(handleMain(array, target).sort((a, b) => a.length - b.length));
